DOMAIN = "ics2000"


def setup(hass, config):
    # hass.states.set("hello_state.world", "Paulus")
    return True
